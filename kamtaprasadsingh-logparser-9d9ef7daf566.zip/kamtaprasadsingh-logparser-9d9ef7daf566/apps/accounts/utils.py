from django.template import loader
from django.core import signing
from django.contrib.auth.models import User
from django.contrib.auth import get_backends
from .models import UserUsage, UserProfile
from apps.product.models import Product
import decimal
import pytz
from datetime import datetime

def authenticate_api(username,key):
    """
    If the given credentials are valid, return a User object.
    """
    try:

        userprofile = UserProfile.objects.get(user__username=username,key=key)
        return userprofile.user
    except UserProfile.DoesNotExist:
        return None
    except:
        return None
        
def site_usage(rows,product_id,userdetail):
    product=Product.objects.get(pk=product_id)
    price=rows*(product.price)/product.quantity
    if price < 0.001:
        price = decimal.Decimal('0.001')
    usage=UserUsage(userusage=userdetail,product=product,quantity=rows,price=price)    
    usage.save()
    userdetail.remaining_amount -= price
    userdetail.used_amount +=price
    userdetail.save()
def check_credit(rows,product_id,userdetail):    
    product=Product.objects.get(pk=product_id)
    price=rows*(product.price)/product.quantity
    if price < 0.001:
        price = decimal.Decimal('0.001')
    if userdetail.remaining_amount < price:
        return True
    return False