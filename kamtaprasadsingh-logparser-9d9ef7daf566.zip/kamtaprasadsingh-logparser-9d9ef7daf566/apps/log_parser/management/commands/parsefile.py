from django.core.management.base import BaseCommand
from commons import emailtool_files, emailtool_parser
from apps.log_parser.models import EmailLog, InputFileData
import json
from django.conf import settings


class Command(BaseCommand):
    help = 'Parse Log File and save json file on s3'

    def handle(self, *args, **options):
        for ii in InputFileData.objects.filter(status='added'):
            inp_path = ii.file_path
            log_server_name = inp_path.split("/")[0]
            path, dest, e = emailtool_files.get_file(inp_path, settings.BASE_DIR+"/media/input.txt")

            if not path:
                ii.message = str(e)
                ii.status = 'Completed'
                ii.save()
                continue

            output_data = emailtool_parser.parse_file(dest)
            # save data in mysql table EmailLog
            EmailLog.objects.bulk_create([EmailLog(log_server_name=log_server_name,queue_id=i,
                                                   message_id=output_data[i]['message_id'] if 'message_id' in
                                                                                              output_data[i] else '',
                                                   from_email=output_data[i]['from'] if 'from' in output_data[
                                                       i] else '',
                                                   to_email=output_data[i]['to'] if 'to' in output_data[i] else '',
                                                   dsn=output_data[i]['dsn'] if 'dsn' in output_data[i] else '',
                                                   status=output_data[i]['status'] if 'status' in output_data[
                                                       i] else '', status_message=output_data[i][
                    'status_message'] if 'status_message' in output_data[i] else '',
                                                   start_date=output_data[i]['start_date'] if 'start_date' in
                                                                                              output_data[i] else '',
                                                   end_date=output_data[i]['end_date'] if 'end_date' in output_data[
                                                       i] else '') for i in output_data])

            emailtool_files.del_file(path)  # delete files from s3

            # save result on s3
            result_dict = {}
            sent_dict={}
            #defered_dict={}
            #bounced_dict={}
            for j in output_data:
                if 'message_id' in output_data[j] and 'dsn' in output_data[j] and 'status' in output_data[j] and 'from' in output_data[j] and 'to' in output_data[j]:
                    #result_dict[output_data[j]['message_id']] = {'dsn': output_data[j]['dsn'],
                    #                                             'status': output_data[j]['status']}
                    if output_data[j]['status'].lower() == "sent":
                        if output_data[j]['from'] in sent_dict:
                            sent_dict.get(output_data[j]['from']).append(output_data[j]['message_id'])
                        else:
                            sent_dict[output_data[j]['from']]=[output_data[j]['message_id']]
                    
                        
                else:
                    continue
            result_dict["sent"]=sent_dict

            with open(settings.BASE_DIR+'/media/data.json', 'w') as outfile:
                json.dump(result_dict, outfile)

            updated_path = "result/" + str(path.split("/")[-1])
            path, src = emailtool_files.save_file(updated_path, settings.BASE_DIR+'/media/data.json')

            if not path:
                ii.message = 'Some error occur in uploading json file on s3'
                ii.status = 'Completed'
                ii.save()
                continue

            ii.message = 'success'
            ii.status = 'Completed'
            ii.save()
