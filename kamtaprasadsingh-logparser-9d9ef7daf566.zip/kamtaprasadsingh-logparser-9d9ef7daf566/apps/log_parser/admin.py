from django.contrib import admin
from .models import EmailLog, InputFileData
from django.contrib import messages
from xlwt import Workbook
from django.http import HttpResponse
from django.contrib.admin.utils import label_for_field
from xlwt import Workbook
from django.utils.html import strip_tags


def exportData(self, request, queryset):
    opts = self.model._meta
    field_names = self.list_display
    if 'action_checkbox' in field_names:
        field_names.remove('action_checkbox')
    headers = []
    wb = Workbook()
    ws = wb.add_sheet('Sheet1')
    r=0
    c=0
    for field_name in list(field_names):

        label = label_for_field(field_name,self.model,self)
        #if str.islower(label):
        try:
            label = str.title(label)
        except:
            label=str.title(field_name)
        ws.write(r, c, label)
        c=c+1
        headers.append(label)
    for row in queryset:
        r=r+1
        c=0
        values = []
        for field in field_names:
            flag=1
            try:
                value=getattr(self, field)
            except:
                value=getattr(row, field)
                flag=2

            if callable(value):
                try:
                    if flag==1:
                        value = value(row)
                    else:
                        value=value()
                except:
                    value = 'Error retrieving value'
            if value is None:
                value = ''
                #values.append(unicode(value).encode('utf-8'))
            val_xls=str(strip_tags(unicode(value).encode('ascii', 'ignore')))
            try:
                val_xls=int(val_xls)
            except:
                try:
                    val_xls=float(val_xls)
                except:
                    val_xls=val_xls
            ws.write(r, c,val_xls)
            c=c+1
    fname = '%s.xls' % unicode(opts).replace('.', '_')
    response = HttpResponse(content_type="application/vnd.ms-excel")
    response['Content-Disposition'] = 'attachment; filename=%s' % fname
    wb.save(response)
    return response



class EmailLogAdmin(admin.ModelAdmin):
    list_display = ('log_server_name','from_email','to_email', 'dsn', 'status', 'message_id','queue_id','status_message','start_date', 'end_date')
    list_filter = ('log_server_name','entry_date', 'dsn', 'status', 'from_email')
    actions = [exportData]


class InputFileDataAdmin(admin.ModelAdmin):
    list_display = ('id', 'file_path', 'status', 'message', 'created', 'modified')
    list_filter = ('status', 'created', 'message')

admin.site.register(EmailLog, EmailLogAdmin)
admin.site.register(InputFileData, InputFileDataAdmin)
