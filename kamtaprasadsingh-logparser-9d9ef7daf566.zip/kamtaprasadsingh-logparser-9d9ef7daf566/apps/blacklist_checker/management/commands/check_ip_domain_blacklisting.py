from django.core.management.base import BaseCommand
from apps.blacklist_checker.models import BlacklistMaster,BlaclistingDetail,IpDatabase
from apps.blacklist_checker.blacklist_check import check_blacklist
from django.conf import settings


class Command(BaseCommand):
    help = 'Will fill Blacklisting in table'

    def handle(self, *args, **options):
        for ip in IpDatabase.objects.filter(active=True):
            bldb=[]
            is_listed = False
            is_ip= not ip.is_domain
            if ip.is_domain:
                bldb = BlacklistMaster.objects.filter(active=True,is_domain=True)
            else:
                bldb = BlacklistMaster.objects.filter(active=True, is_ip=True)
            BlaclistingDetail.objects.filter(ip_database=ip).delete()
            for bl in bldb:
                status, ip_val, bl_url, answer, answer_text = check_blacklist(ip.ip_or_domain,bl.url,is_ip)
                if status:
                    is_listed = True
                if status:
                    blacklistingdetail=BlaclistingDetail(ip_database=ip,master=bl,is_blacklisted=status,answer=answer,answer_text = answer_text )
                else:
                    blacklistingdetail = BlaclistingDetail(ip_database=ip, master=bl, is_blacklisted=status,response= answer)
                blacklistingdetail.save()
            ip.is_blacklisted=is_listed
            ip.save()