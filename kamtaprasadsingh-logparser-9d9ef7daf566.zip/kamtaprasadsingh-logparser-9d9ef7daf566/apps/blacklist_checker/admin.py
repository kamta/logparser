from django.contrib import admin
from .models import *


class IpDatabaseAdmin(admin.ModelAdmin):
    list_display = ('ip_or_domain','current_ipreputation','is_blacklisted','is_domain','active','user','updated')
class BlacklistMasterAdmin(admin.ModelAdmin):
    list_display = ('service_provider_name','url','is_ip','is_domain','priority','active')
    #list_editable = ('is_ip','is_domain','priority','active')
    list_filter = ('is_ip','is_domain','priority','active')
class IpReputationHistoryAdmin(admin.ModelAdmin):
    list_display = ('ip','ipreputation','added_date','modified_date')
class BlacklistingDetailAdmin(admin.ModelAdmin):
    list_display = ('ip_database','master','is_blacklisted','response','answer','answer_text','added_date')
    list_filter = ('ip_database','is_blacklisted','added_date')


admin.site.register(IpDatabase, IpDatabaseAdmin)
admin.site.register(BlacklistMaster,BlacklistMasterAdmin)
admin.site.register(IpReputationHistory,IpReputationHistoryAdmin)
admin.site.register(BlaclistingDetail,BlacklistingDetailAdmin)
