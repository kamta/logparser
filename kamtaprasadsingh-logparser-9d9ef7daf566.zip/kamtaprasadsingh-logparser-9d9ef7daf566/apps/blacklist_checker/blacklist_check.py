import dns.resolver
import sys
def check_blacklist(myIP,bl,is_ip=True):
    try:
        my_resolver = dns.resolver.Resolver()
        if is_ip:
            query = '.'.join(reversed(str(myIP).split("."))) + "." + bl
        else:
            query = str(myIP) + "." + bl
        answers = my_resolver.query(query, "A")
        answer_txt = my_resolver.query(query, "TXT")
        return True, myIP, bl, answers[0], answer_txt[0]
        #print 'IP: %s IS listed in %s (%s: %s)' % (myIP, bl, answers[0], answer_txt[0])
    except dns.resolver.NXDOMAIN:
        #print 'IP: %s is NOT listed in %s' % (myIP, bl)
        return False, myIP, bl, "Not Listed", ""
    except dns.resolver.Timeout:
        return False, myIP, bl, "TimeOut", ""
    except dns.resolver.NoAnswer:
        return False, myIP, bl, "No Answer", ""
    except Exception as e:
        return False, myIP, bl, str(e), ""