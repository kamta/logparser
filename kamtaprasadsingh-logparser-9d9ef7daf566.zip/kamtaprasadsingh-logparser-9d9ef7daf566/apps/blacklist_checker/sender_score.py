#!/usr/bin/python
#
# Here's a plugin which lets you monitor your senderscore.org reputation. For
# people sending a large amount of email - this might be useful.


import socket
import sys
import os

def get_senderscores(ip):
    tmp = ip.split(".")
    backwards = "%s.%s.%s.%s" % (tmp[3], tmp[2], tmp[1], tmp[0])
    # replists = ['cmplt.rating.senderscore.com', 'score.senderscore.com', 'uus.rating.senderscore.com', 'vol.rating.senderscore.com', 'filtered.rating.senderscore.com']
    replists = ['score.senderscore.com']
    lookup_results = {}
    for rl in replists:
            try:
                    host = '%s.%s' % (backwards, rl)
                    ret = socket.gethostbyname(host)
                    if ret:
                            lookup_results[rl] = ret
            except Exception, e:
                    print >> sys.stderr,e
    scores = {}
    for k in lookup_results.keys():
        v = lookup_results[k].split('.')[3]
        k = k.split(".")[0]
        scores[k] = v
    return scores

'''def print_stats(ip):
    scores = get_senderscores(ip)
    for key in scores.keys():
        return key+".value "+scores[key]'''
