from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^mysite/ips/$', views.ips_list, name='ips_list'),
    url(r'^mysite/ips/add/$', views.ip_change, name="ip_change"),
    url(r'^mysite/ips/delete/(?P<id>.+)/$', views.ip_delete, name="ip_delete"),
    url(r'^mysite/domains/$', views.domains_list, name='domains_list'),
    url(r'^mysite/domains/add/$', views.domain_change, name="domain_change"),
    url(r'^mysite/domains/delete/(?P<id>.+)/$', views.ip_delete, name="domain_change"),
    url(r'^mysite/ips/blacklisting-detail/(?P<id>.+)/$', views.blacklisting_detail, name='blacklisting_detail'),
    url(r'^mysite/sender/ip/score/(?P<id>.+)/$', views.sender_ip_score, name="sender_ip_score"),
    
    

]
