from django.shortcuts import HttpResponse
from .models import IpDatabase,BlaclistingDetail
from datetime import datetime, timedelta
from django.utils import timezone
from django.shortcuts import render
from .sender_score import get_senderscores
from django.http import HttpResponseRedirect


def ips_list(request):
    ip=IpDatabase.objects.filter(active=True,is_domain=False)
    if not request.user.is_staff:
        ip=ip.filter(user=request.user)
    template_name = 'myadmin/ips_list.html'
    return render(request, template_name, {'ips_obj':ip})
def ip_change(request):
    template_name='myadmin/ip_change.html'
    if request.method == "POST":        
        name=request.POST.get("ip")
        ip=IpDatabase()
        ip.ip_or_domain = name 
        ip.is_domain=False
        ip.user = request.user 
        ip.save()
        return HttpResponseRedirect("/mysite/ips/")    
    return render(request, template_name, {})

def ip_delete(request,id):    
    ip=IpDatabase.objects.get(id=id)
    ip.active=False
    ip.save()
    if ip.is_domain:
        return HttpResponseRedirect("/mysite/domains/")
    return HttpResponseRedirect("/mysite/ips/")
def domains_list(request):
    ip=IpDatabase.objects.filter(active=True,is_domain=True)
    if not request.user.is_staff:
        ip=ip.filter(user=request.user)
    template_name = 'myadmin/domains_list.html'
    return render(request, template_name, {'ips_obj':ip})
def domain_change(request):
    template_name='myadmin/domain_change.html'
    if request.method == "POST":        
        name=request.POST.get("domain")
        ip=IpDatabase()
        ip.ip_or_domain = name 
        ip.is_domain=True
        ip.user = request.user 
        ip.save()
        return HttpResponseRedirect("/mysite/domains/")    
    return render(request, template_name, {})
def sender_ip_score(request,id=None):
    smtp=IpDatabase.objects.get(id=id)
    rating=get_senderscores(smtp.ip_or_domain)
    score=rating.get('score',-1)
    template_name='myadmin/ip_reputation.html'
    return render(request, template_name,{'rating':score,'ip':smtp.ip_or_domain})

def blacklisting_detail(request,id):
    ip=IpDatabase.objects.get(id=id)
    blacklisting_detail=BlaclistingDetail.objects.filter(ip_database=ip)
    template_name = 'myadmin/blacklisting_detail.html'
    return render(request, template_name, {'ips_obj':blacklisting_detail,'ip':ip})
