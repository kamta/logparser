from django.conf.urls import url
from django.views.generic import TemplateView

urlpatterns = [
    url(r'^docs/$', TemplateView.as_view(template_name='docs/docs.html'), name="docs"), 
    url(r'^docs/api/blacklist-monitoring/$', TemplateView.as_view(template_name='docs/blacklist-monitoring-api.html'), name="docs_blacklist_api") 
]
