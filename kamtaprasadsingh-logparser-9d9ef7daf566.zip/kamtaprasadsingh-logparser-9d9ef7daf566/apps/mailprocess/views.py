from django.shortcuts import render
from django.conf import settings
from django.http import HttpResponse,HttpResponseRedirect
import json
from .models import ContactUs,Country
from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from apps.product.models import Product
from apps.accounts.models import UserUsage
    
def home(request):
    template_name='index.html'
    return render(request, template_name,{'country_list':Country.objects.all()})

def pricing(request):
    product=Product.objects.filter(active=True)
    template_name='myadmin/pricing.html'
    return render(request, template_name,{'product':product})    
    
def pricing(request):
    product=Product.objects.filter(active=True)
    template_name='myadmin/pricing.html'
    return render(request, template_name,{'product':product})
def contactus(request):
    if request.method == "POST":
        try:
            contact=ContactUs()
            contact.name=request.POST.get('name')
            contact.email=request.POST.get('email')
            contact.message=request.POST.get('message')
            contact.skypeid=request.POST.get('skypeid')
            contact.mobile=int(request.POST.get('whatsapp_number'))
            contact.country_id=int(request.POST.get('country'))
            contact.status=1
            contact.save()
            return HttpResponse(json.dumps(1),content_type="application/json")
        except:
            return HttpResponse(json.dumps(2),content_type="application/json")
        
@login_required(login_url='/')
def mysite(request):    
    template_name = 'myadmin/index.html'
    return render(request, template_name, {})
        