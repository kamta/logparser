from django.conf.urls import url
from django.views.generic import TemplateView
from .views import *

urlpatterns = [
    url(r'^$', home, name="homepage"),
    url(r'^pricing/$', pricing, name="pricing"),
    url(r'^contactus/$', contactus, name="contactus"),
    url(r'^mysite/$', mysite, name='mysite'),
]