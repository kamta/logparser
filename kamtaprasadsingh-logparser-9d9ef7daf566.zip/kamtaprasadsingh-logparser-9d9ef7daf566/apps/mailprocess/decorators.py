from functools import wraps
from django.utils.decorators import available_attrs
import json
from django.http import HttpResponse
from django.shortcuts import resolve_url
def login_required_ajax(view_func):
    @wraps(view_func, assigned=available_attrs(view_func))
    def _wrapped_view(request, *args, **kwargs):
        if request.user.is_authenticated:
            return view_func(request, *args, **kwargs)               
        else:
            if request.is_ajax():# or request.method == "POST": 
                return HttpResponse(json.dumps(5),content_type="application/json")   
            else:
                #path = request.build_absolute_uri()
                path = request.get_full_path()
                resolved_login_url = resolve_url("/")
                from django.contrib.auth.views import redirect_to_login
                return redirect_to_login(path, resolved_login_url)                
    return _wrapped_view