========================
emailtool_site
========================

This is the application to serve dailymails.   To use this project follow these steps:

#. Make sure you have Python 2.7


Working Environment
===================



Installation of Dependencies
=============================

Depending on where you are installing dependencies:

In development::

    $ pip install -r requirements/local.txt

For production::

    $ pip install -r requirements.txt
    
    
    http://multirbl.valli.org/