import re


def parse_file(path):
    '''
    Parse file from to extract email stats
    :param path: The path to the file that will be access.
    :return: A dict obj.
    '''

    with open(path, 'r') as fi:

        regex_group = {
            'queue_id': r'([A-Z0-9]{7,12})+:',
            "message-id": r"message-id=<([^>]*)>",
            "from": r"from=<([^>]*)>",
            "to": r"to=<([^>]*)>",
            "status": r"status=([a-z]+) \((.+)\)",
            "dsn": r"dsn=([0-9]\.[0-9]\.[0-9])",
            "start_date": r"client=",
            "date": r"(?P<month>\w+)\s+(?P<day>\d+)\s+(?P<hour>\d+):(?P<min>\d+):(?P<sec>\d+)"

        }
        output_data = {}
        i = 0
        for line in fi:
            r = re.search(regex_group['queue_id'], line)
            if r:
                clean_r = r.group().strip(":")

                if clean_r in output_data:
                    pass
                else:
                    output_data[clean_r] = {}

                message_id = re.search(regex_group['message-id'], line)
                if message_id and 'message_id' not in output_data[clean_r]:
                    output_data[clean_r]['message_id'] = message_id.group().strip("message-id=<").strip(">")

                from_q = re.search(regex_group['from'], line)
                if from_q and 'from_q' not in output_data[clean_r]:
                    output_data[clean_r]['from'] = from_q.group().strip("from=<").strip(">")

                to = re.search(regex_group['to'], line)
                if to and 'to' not in output_data[clean_r]:
                    output_data[clean_r]['to'] = to.group().strip("to=<").strip(">")

                dsn = re.search(regex_group['dsn'], line)
                if dsn and 'dsn' not in output_data[clean_r]:
                    output_data[clean_r]['dsn'] = dsn.group().strip("dsn=")

                start_date = re.search(regex_group['start_date'], line)
                if start_date and 'start_date' not in output_data[clean_r]:
                    star_date = re.search(regex_group['date'], line)
                    output_data[clean_r]['start_date'] = star_date.group()

                status = re.search(regex_group['status'], line)
                if status and 'status' not in output_data[clean_r]:
                    end_date = re.search(regex_group['date'], line)
                    output_data[clean_r]['end_date'] = end_date.group()
                    output_data[clean_r]['status'], output_data[clean_r]['status_message'] = \
                    status.group().strip("status").strip("=").split(" (")[0], \
                    status.group().strip("status").strip("=").strip(")").split(" (")[1]

        return output_data
