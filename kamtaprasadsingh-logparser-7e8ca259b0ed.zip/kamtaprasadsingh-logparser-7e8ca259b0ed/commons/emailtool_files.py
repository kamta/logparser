from django import conf

import boto3


def get_file(path, local_file_path):
    '''
    Access file from S3 server
    :param path: The path to the file that will be access.
    :return: A validated s3 path and local file path to process.
    '''
    
    try:
        s3 = boto3.resource('s3', aws_access_key_id=conf.settings.AWS_S3_ACCESS_KEY_ID,
                            aws_secret_access_key=conf.settings.AWS_S3_SECRET_ACCESS_KEY)

        key = path  # 'mail/2018-07-06_00.00.01.247228_mail.log'
        dest = local_file_path  # 'media/a.txt'
        s3.Bucket(conf.settings.AWS_STORAGE_BUCKET_NAME).download_file(key, dest)

    except Exception as e:
        print e
        return '', '', e

    return path, dest, ''


def save_file(path, local_file_path):
    '''
    save file to S3 server
    :param path: The path to the file that will be access.
    :return: A validated s3 path and local file path to process.
    '''
    try:
        s3 = boto3.resource('s3', aws_access_key_id=conf.settings.AWS_S3_ACCESS_KEY_ID,
                            aws_secret_access_key=conf.settings.AWS_S3_SECRET_ACCESS_KEY)

        key = path  # 'mail/2018-07-06_00.00.01.247228_mail.log'
        src = local_file_path  # 'media/a.txt'
        s3.Bucket(conf.settings.AWS_STORAGE_BUCKET_NAME).upload_file(src, key)

    except Exception as e:
        print e
        return '', ''

    return path, src


def del_file(path):
    '''
    delete file from S3 server
    :param path: The path to the file that will be delete.
    :return: bool object.
    '''

    try:
        s3 = boto3.resource('s3', aws_access_key_id=conf.settings.AWS_S3_ACCESS_KEY_ID,
                            aws_secret_access_key=conf.settings.AWS_S3_SECRET_ACCESS_KEY)
        s3.Object(conf.settings.AWS_STORAGE_BUCKET_NAME, path).delete()
    except Exception as e:
        print e
        return False

    return True
