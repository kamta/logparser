jQuery.validator.addMethod("alphanumericonly", function(value, element) {
	return this.optional(element) || /^[a-z0-9]*$/i.test(value);
}, "Small Letters and numbers only please");

$("#userregistrationbutton").click(function(){

                $('#site-user-registration-form').validate({ // initialize the plugin
                    rules: {
                        email: {
                            required: true,
                            email: true
                        },
                        username: {
                            required: true,
                            alphanumericonly: true
                        },
                        mobile: {
                            required: true,
                            digits: true,
                            minlength : 10,
                            maxlength : 15
                        },
                        password: {
                            required: true,
                            minlength : 5
                        }
                    },
                    submitHandler: function (form) {

                    $('#userregistrationbutton').attr('disabled', 'disabled').html('Please Wait ...');
                        $.ajax({
                           type: "POST",
                           url: "/accounts/register/user/",
                           data: $("#site-user-registration-form").serialize(), // serializes the form's elements.
                           success: function(data)
                           {
                               if (data == 1)
                               {
                                   $('.alert-success').removeClass('hidden');
                                   $('.alert-info').addClass('hidden');                                   
                                   $('.form-control').val("");
				   setTimeout(function(){
			              document.location="/mysite/";
					}, 5000);
                               }
                               if (data == 2)
                               {
                                   $('.alert-info').removeClass('hidden');
                                   $('.alert-success').addClass('hidden');

                               }
                               $('#userregistrationbutton').removeAttr('disabled').html('Submit');

                           }
                         });
                    }
                });



            });

 $("#contact_button").click(function(){
                $('#contactform').validate({ // initialize the plugin
                    rules: {
                        uploaded_file:{
                            required:true,
                            extension: "xls"//"csv|xls|xlsx"
                        },
                        name: {
                            required: true,
                            minlength:5
                    }
                    },
                    submitHandler: function (form) {
                    var formData = new FormData(form);
                    $('#contact_button').attr('disabled', 'disabled').html('Please Wait ...');
                        $.ajax({
                           type: "POST",
                           url: $(form).action,
                           data: formData, // serializes the form's elements.
                           mimeType: "multipart/form-data",
                           contentType: false,
                           cache: false,
                           processData: false,
                           dataType : 'json',
                           success: function(data)
                           {

                               if (data == 1)
                               {
                                 document.location="/mysite/contact/";

                               }
                               else if (data == 5){
                                document.location="/";
                                
                               }
                               else
                               {
                                   $('.error-message').show();
                                   errorval=""
                                   for (var key in data) {
                                       errorval += key +" :  "+ data[key] + "<br>"
                                    }
                                   $('.error-message').html(errorval);

                               }
                               $('#contact_button').removeAttr('disabled').html('Submit');

                           }
                         });
                    }
                });



 });


 

 $("#btn_contact_submit").click(function(){

                $('#contact-form').validate({ // initialize the plugin
                    rules: {
                        email: {
                            required: true,
                            email: true
                        },
                        name: {
                            required: true
                        },
			//skypeid: {
		        //    required: true
			//    },
			whatsapp_number: {
			    required: true,
                            digits: true,
                            minlength : 10,
                            maxlength : 15
		    },
                        message: {
                            required: true,
                            minlength : 50
                        }
                    },
                    submitHandler: function (form) {

                    $('#btn_contact_submit').attr('disabled', 'disabled').html('Please Wait ...');
                        $.ajax({
                           type: "POST",
                           url: "/contactus/",
                           data: $("#contact-form").serialize(), // serializes the form's elements.
                           success: function(data)
                           {


                               if (data == 1)
                               {
                                  $('.alert-info').show();
                                   $('.alert-warning').hide();
                                   $('.form-control').val("");

                               }
                               //if (data == 2)
                               else
                               {
                                   $('.alert-warning').show();
                                   $('.alert-info').hide();

                               }
                               $('#btn_contact_submit').removeAttr('disabled').html('Send Message');

                           }
                         });
                    }
                });



            });

 $("#userprofiles_button").click(function(){

                $('#userprofile-form').validate({ // initialize the plugin
                    rules: {

                        first_name: {
                            required: true
                        },

                        mobile: {
                            required: true,
                            digits: true,
                            minlength : 10,
                            maxlength : 10
                        }
                    },
                    submitHandler: function (form) {

                    $('#userprofiles_button').attr('disabled', 'disabled').html('Please Wait ...');
                        $.ajax({
                           type: "POST",
                           url: "/accounts/",
                           data: $("#userprofile-form").serialize(), // serializes the form's elements.
                           success: function(data)
                           {

                               if (data == 1)
                               {
                                 document.location="/accounts";

                               }
                               else if (data == 5){
                                document.location="/";
                                
                               }
                               else
                               {
                                   $('#userprofile-form .alert-warning').removeClass('hidden');


                               }
                               $('#userprofiles_button').removeAttr('disabled').html('Submit');

                           }
                         });
                    }
                });



            });

 $("#companydetails_button").click(function(){

                $('#companydetails-form').validate({ // initialize the plugin
                    rules: {

                        company: {
                            required: true,
                            minlength:6
                        },

                        website: {
                            required: true,
                            minlength : 5
                        },
                        address: {
                            required: true,
                            minlength : 5
                        }
                    },
                    submitHandler: function (form) {

                    $('#companydetails_button').attr('disabled', 'disabled').html('Please Wait ...');
                        $.ajax({
                           type: "POST",
                           url: "/accounts/companydetails/",
                           data: $("#companydetails-form").serialize(), // serializes the form's elements.
                           success: function(data)
                           {

                               if (data == 1)
                               {
                                 document.location="/accounts/";

                               }
                               else if (data == 3){
                                   document.location="/";
                               }
                               else
                               {
                                   $('#companydetails-form .alert-warning').removeClass('hidden');


                               }
                               $('#companydetails_button').removeAttr('disabled').html('Submit');

                           }
                         });
                    }
                });



            });

 $("#changepassword_button").click(function(){

                $('#changepassword-form').validate({ // initialize the plugin
                    rules: {

                        new_password: {
                            required: true
                        },

                        confirm_password: {
                            equalTo: "#new_password"
                        }
                    },
                    submitHandler: function (form) {

                    $('#changepassword_button').attr('disabled', 'disabled').html('Please Wait ...');
                        $.ajax({
                           type: "POST",
                           url: "/accounts/change/password/",
                           data: $("#changepassword-form").serialize(), // serializes the form's elements.
                           success: function(data)
                           {

                               if (data == 1)
                               {
                                 document.location="/";

                               }
                               else if (data == 3){
                                   document.location="/";
                               }
                               else
                               {
                                   $('.alert-warning').removeClass('hidden');


                               }
                               $('#changepassword_button').removeAttr('disabled').html('Submit');

                           }
                         });
                    }
                });



            });


 




  $("a.contact-validate").click(function(){
	  
	  confirm_val = confirm("Are you sure?It is paid features.");
	  if (confirm_val == false) {
		  return false;
	  }

        href=$(this).attr("href");
        obje=$(this)
        $(this).attr("href","#").html('Please Wait ...');
        $(this).unbind('click');
        $.ajax({
                           type: "GET",
                           url: href,
                           data: '',
                           dataType : 'json',
                           success: function(data)
                           {

                               if (data == 1)
                               {
                                obje.html('Validating');
                                $(".contactlist-success span").html("List is Validating Now, It will take some times to complete. Please follow after some time.");

                               }
                             else if (data == 2){
                                $(".contactlist-success span").html("Your Email Validation Credit is less to validate this contact list. Please recharge your account or reduce contact list size");
                                
                               }
                               else if (data == 5){
                                
                                document.location="/";
                                
                               }
                               else
                               {

                                $(".contactlist-success span").html("Something wrong happen.");
                               }
                                $(".contactlist-success").show();

                           }


                         });

return false;



 });

  