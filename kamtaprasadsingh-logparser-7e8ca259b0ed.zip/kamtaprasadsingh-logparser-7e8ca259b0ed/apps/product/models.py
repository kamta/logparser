from django.db import models
from django.utils.translation import ugettext_lazy as _
PRODUCT_CHOICE =((1,"Tests"),)
class Product(models.Model):    
    name=models.CharField(max_length=100,null=True,blank=True)
    price=models.DecimalField(max_digits=10,decimal_places=2,default=0.00)
    quantity=models.IntegerField()
    unit=models.IntegerField(choices=PRODUCT_CHOICE,default=1)
    active=models.BooleanField(default=0)
    is_addon=models.BooleanField(default=0)    
    def __unicode__(self):
        return str(self.name)