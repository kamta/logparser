from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import ugettext_lazy as _

class BlacklistMaster(models.Model):
    service_provider_name=models.CharField(max_length=150,unique=True)
    url=models.CharField(_("Domain"),max_length=150)
    is_domain=models.BooleanField(default=False)
    is_ip=models.BooleanField(default=False)
    priority=models.IntegerField(default=0)
    active=models.BooleanField(default=True)
    def __unicode__(self):
        return self.service_provider_name + "--" + self.url
class IpDatabase(models.Model):
    ip_or_domain = models.CharField(_("IP or Domain"),max_length=150,unique=True) 
    current_ipreputation=models.IntegerField(_("Current IP Reputation"),default=0)
    is_blacklisted=models.BooleanField(default=False)
    is_domain=models.BooleanField(default=False)
    active=models.BooleanField(default=True)
    updated = models.DateTimeField(auto_now=True)
    user = models.ForeignKey(User)    
    def __unicode__(self):
        return str(self.ip_or_domain)
class IpReputationHistory(models.Model):
    ip = models.ForeignKey(IpDatabase)
    ipreputation=models.IntegerField(_("IP Reputation"),default=0)  
    added_date=models.DateTimeField(auto_now_add=True)
    modified_date=models.DateTimeField(auto_now=True)
'''class Blacklisting(models.Model):
    ip = models.ForeignKey(IpDatabase)
    is_blacklisted=models.BooleanField(default=False)
    added_date=models.DateTimeField(auto_now_add=True)'''  

class BlaclistingDetail(models.Model):
    ip_database=models.ForeignKey(IpDatabase)
    master=models.ForeignKey(BlacklistMaster)
    is_blacklisted=models.BooleanField(default=False)
    response=models.TextField(blank=True, null=True)
    answer=models.CharField(_("Answer"),max_length=150,null=True,blank=True)
    answer_text = models.TextField(blank=True, null=True)
    added_date=models.DateTimeField(auto_now_add=True)
    

    
 



