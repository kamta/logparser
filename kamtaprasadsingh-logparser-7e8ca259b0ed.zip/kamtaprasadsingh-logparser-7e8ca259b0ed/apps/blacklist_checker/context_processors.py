from .models import IpDatabase
def site_data(request):
    """
    Returns a lazy 'messages' context variable.
    """
    if request.user.is_authenticated():
        return {
            'ips_count': IpDatabase.objects.filter(user=request.user,is_domain=False,active=True).count(),
            'domains_count': IpDatabase.objects.filter(user=request.user,is_domain=True,active=True).count(),
           
        }
    else:
        return {            
        }