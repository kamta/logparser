from django.core.management.base import BaseCommand
from apps.blacklist_checker.models import IpDatabase,IpReputationHistory
from apps.blacklist_checker.sender_score import get_senderscores
from django.conf import settings


class Command(BaseCommand):
    help = 'Will fill IP Reputation in table'

    def handle(self, *args, **options):
        for ip in IpDatabase.objects.filter(active=True,is_domain=False):
            rating=get_senderscores(ip.ip_or_domain)
            score=rating.get('score',-1)
            ip.current_ipreputation=score
            ip.save()
            history=IpReputationHistory()
            history.ip=ip
            history.ipreputation=score
            history.save()