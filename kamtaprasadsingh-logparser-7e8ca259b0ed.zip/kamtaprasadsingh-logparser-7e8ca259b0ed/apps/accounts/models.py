from django.db import models
from django.contrib.auth.models import User
from apps.mailprocess.models import Country
from django.utils.translation import ugettext_lazy as _
from apps.product.models import Product
STATUS_CHOICE = ((1,"Registration Completed"),(2,"Account UnderReview"),
                 (3,"Accounts Verified"))#,(4,"Account Activated"))

class UserProfile(models.Model):
    user = models.OneToOneField(User,related_name="userdetail")
    mobile = models.BigIntegerField()
    company=models.CharField(max_length=100,null=True,blank=True)
    address=models.TextField(null=True,blank=True)
    country_detail=models.ForeignKey(Country,null=True,blank=True)
    website = models.CharField(_('domain name'),null=True,blank=True,max_length=100)
    userstatus = models.IntegerField(choices=STATUS_CHOICE,default=1)
    total_amount=models.DecimalField(max_digits=10,decimal_places=3,default=0.00)
    remaining_amount=models.DecimalField(max_digits=10,decimal_places=3,default=0.00)
    used_amount=models.DecimalField(max_digits=10,decimal_places=3,default=0.00)    
    skypeid=models.CharField(max_length=100,null=True,blank=True)
    key=models.CharField(max_length=30,null=True,blank=True)
    is_api_enabled=models.BooleanField(default=False)
    def __unicode__(self):
        return str(self.user.username)

class UserUsage(models.Model):
    userusage = models.ForeignKey(UserProfile,related_name="usrusage")  
    product=models.ForeignKey(Product)
    quantity=models.IntegerField(default=0)
    price=models.DecimalField(max_digits=10,decimal_places=3,default=0.00)
    active=models.BooleanField(default=True)
    date=models.DateTimeField(auto_now_add=True)