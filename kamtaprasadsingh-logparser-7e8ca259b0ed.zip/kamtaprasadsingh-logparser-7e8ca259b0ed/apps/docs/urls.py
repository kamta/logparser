from django.conf.urls import url
from django.views.generic import TemplateView

urlpatterns = [
    url(r'^docs/$', TemplateView.as_view(template_name='docs/docs.html'), name="docs"), 
    url(r'^docs/api/blacklist-monitoring/$', TemplateView.as_view(template_name='docs/blacklist-monitoring-api.html'), name="docs_blacklist_api"),
    url(r'^docs/api/sender-score/$', TemplateView.as_view(template_name='docs/sender-score-api.html'), name="docs_sender_api"),
    url(r'^docs/api/gmail-tab-tracking/$', TemplateView.as_view(template_name='docs/gmail-tab-tracking-api.html'), name="docs_gmailtab_api"),
    url(r'^docs/api/inbox-rate-tracking/$', TemplateView.as_view(template_name='docs/inbox-rate-tracking-api.html'), name="docs_inboxrate_api"),

]
