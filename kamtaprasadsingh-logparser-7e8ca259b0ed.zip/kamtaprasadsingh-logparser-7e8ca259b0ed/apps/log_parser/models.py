import datetime
import mongoengine
from django.db import models
from django.contrib.auth.models import User


class EmailLog(models.Model):
    queue_id = models.CharField(max_length=150, blank=False, null=False, db_index=True)
    message_id = models.CharField(max_length=150, blank=True, null=True, db_index=True)
    from_email = models.EmailField(blank=True, null=True)
    to_email = models.EmailField(blank=True, null=True)
    dsn = models.CharField(max_length=30, blank=True, null=True)
    status = models.CharField(max_length=100, blank=True, null=True)
    status_message = models.TextField(blank=True, null=True)
    start_date = models.CharField(max_length=100, blank=True, null=True)
    end_date = models.CharField(max_length=100, blank=True, null=True)
    entry_date = models.DateTimeField(auto_now_add=True)
    log_server_name = models.CharField(max_length=30, blank=True, null=True)


class InputFileData(models.Model):
    STATUS_CHOICES = (
        ('added', 'added'),
        ('Completed', 'Completed')
    )

    file_path = models.CharField(max_length=150, blank=True, null=True)
    status = models.CharField(max_length=150, choices=STATUS_CHOICES)
    message = models.TextField(blank=True, null=True)
    created = models.DateTimeField(auto_now_add=True)
    modified = models.DateTimeField(auto_now=True)


class EmailLogBackup(mongoengine.Document):
    queue_id = mongoengine.StringField(max_length=256, required=True)
    message_id = mongoengine.StringField(max_length=1024, required=False)
    from_email= mongoengine.StringField(max_length=1024, required=False)
    to_email = mongoengine.StringField(max_length=1024, required=False)
    dsn = mongoengine.StringField(max_length=256, required=False)
    status = mongoengine.StringField(max_length=1024)
    status_message = mongoengine.StringField(max_length=2048)
    start_date = mongoengine.DateTimeField(required=False)
    end_date = mongoengine.DateTimeField(required=False)
    entry_date = mongoengine.DateTimeField(default=datetime.datetime.utcnow)

    meta = {
        'indexes': ['message_id', 'status', 'dsn'],
    }
