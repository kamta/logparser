from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^submit-log/$', views.submit_log, name='submit_log'),
    url(r'^mysite/report/serverbased/$', views.serverbased, name='serverbased'),
    url(r'^mysite/report/download/$', views.downloadreport, name='downloadreport'),
    
]
