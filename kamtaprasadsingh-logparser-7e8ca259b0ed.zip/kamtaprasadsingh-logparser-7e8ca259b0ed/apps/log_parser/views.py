from django.shortcuts import HttpResponse
from .models import InputFileData,EmailLog
from django.shortcuts import render
from django.db.models import Count
import csv
from django.http import StreamingHttpResponse
from .utils import Echo
from django.contrib.admin.views.decorators import staff_member_required


def submit_log(request):
    inp_path = request.GET.get("path", '')
    if not inp_path:
        return HttpResponse("Please Provide a Key", status=500)  # not provide a s3 file url
    InputFileData.objects.create(file_path=inp_path, status="added")
    return HttpResponse("Success", status=200)

@staff_member_required
def serverbased(request):
    server=request.GET.get("server",None)
    emaillog=EmailLog.objects.all()
    if server:
        emaillog=emaillog.filter(log_server_name=server)
    data_count=emaillog.count()
    data=emaillog.values('status').annotate(statuscount=Count('id')).order_by('-statuscount')
    template_name = 'myadmin/report_statusbased.html'
    return render(request, template_name, {'data':data,'data_count':data_count})

@staff_member_required
def downloadreport(request):    
    server=request.GET.get("server",None)
    status=request.GET.get("status",None)
    emaillog=EmailLog.objects.all()
    if server:
        emaillog=emaillog.filter(log_server_name=server)
    if status:
        emaillog=emaillog.filter(status=status)    
    if emaillog.count() > 50000:
        emaillog=emaillog[:50000]
    rows = [['Server Name','From Email','To Email','DSN','Status','Message','Start Date','End Date','Entry Date']]    
    
    data = [[e.log_server_name, e.from_email, e.to_email, e.dsn, e.status, e.status_message,e.start_date,e.end_date,e.entry_date] for e in emaillog]
    rows.extend(data)
    pseudo_buffer = Echo()
    writer = csv.writer(pseudo_buffer)
    response = StreamingHttpResponse((writer.writerow(row) for row in rows),
                                     content_type="text/csv")
    response['Content-Disposition'] = 'attachment; filename="email_report.csv"'
    return response

